
<?php $__env->startSection('title'); ?>
    Product Show
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <div class="row">
            <div class="col-lg-6">
                <h2> Show Product</h2>
            </div>
            <div class="col-lg-6 text-right">
                <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>"> Back</a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <img src="<?php echo e(asset($product->image)); ?>" class="card-img-top" alt="...">
        <div class="row">
            <div class="col-6">
                <p class="text-center text-danger"><?php echo e($product->product_id); ?></p>
            </div>
            <div class="col-6 text-right">
                <p class="text-center text-danger"><?php echo e(date('d M Y', strtotime($product->created_at))); ?></p>
            </div>
        </div>
        
        <h2 class="text-center"><?php echo e($product->name); ?></h2>
        <p class="text-center"><?php echo $product->description; ?></p>
    </div>
</div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\product-management\resources\views/products/show.blade.php ENDPATH**/ ?>