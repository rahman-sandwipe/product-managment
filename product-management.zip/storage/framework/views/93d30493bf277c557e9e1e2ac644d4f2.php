
<?php $__env->startSection('title'); ?>
    Data Record
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main>
    <h2 class="text-center">Products Records</h2>
    <table class="table table-striped">
        
        <tr>
            <th>SL</th>
            <th>IMG</th>
            <th>Title</th>
            <th>Details</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><img src="<?php echo e(asset($item->image)); ?>" width="50" alt="product-<?php echo e($item->image); ?>"></td>
            <td><?php echo e($item->name); ?></td>
            <td><?php echo $item->description; ?></td>
            <td style="width: 27%">
                
                <a href="<?php echo e(route('products.edit',$item->id)); ?>" class="btn btn-primary btn-sm"><i class="bi bi-pencil-square"></i> Edit</a>
                <a href="<?php echo e(route('products.destroy',$item->id)); ?>" class="btn btn-primary btn-sm"><i class="bi bi-trash"></i> Delete</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\product-management\resources\views/product/index.blade.php ENDPATH**/ ?>