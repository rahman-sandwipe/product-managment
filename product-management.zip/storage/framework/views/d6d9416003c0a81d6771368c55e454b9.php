
<?php $__env->startSection('title'); ?>
    DATA INSERT
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<main>
    <h2 class="text-center">Insert New Product</h2>
    <form action="<?php echo e(route('product.store')); ?>" method="POST" class="mb-5 mt-5" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3 mt-3">
            <label for="name">Title:</label>
            <input type="text" class="form-control" id="name" placeholder="Enter name" name="name">
        </div>
        
        <div class="mb-3 mt-3">
            <label for="price">Price</label>
            <input type="number" class="form-control" id="price" placeholder="Enter price" name="price">
        </div>
        
        <div class="mb-3 mt-3">
            <label for="stock">Stock</label>
            <input type="number" class="form-control" id="stock" placeholder="Enter stock" name="stock">
        </div>
        
        <div class="mb-3 mt-3">
            <label for="inputFile">Images</label>
            <input type="file" class="form-control" id="inputFile" name="image">
        </div>
        <div class="mb-1 mt-1 img-thumbnail" style="width: 110px; height: 110px; overflow:hidden">
            <div class="preview-images-zone"></div>
        </div>
        
        <div class="mb-3">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" placeholder="Enter description" rows="3" name="description"></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary btn-block">INSERT</button>
    </form>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        // Display image preview
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    var html = '<div class="preview-image"><img src="' + e.target.result + '" width="95"></div>';
                    $('.preview-images-zone').append(html);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        // Trigger image preview when file input changes
        $("input[name='image']").change(function() {
            readURL(this);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\LARAVEL_11\product-management\resources\views/product/create.blade.php ENDPATH**/ ?>